<?php

return [
    'prefix' => [
        'backend' => 'backend',
        'frontend' => 'frontend'
    ],
    'moduleName' => 'staff'
];
