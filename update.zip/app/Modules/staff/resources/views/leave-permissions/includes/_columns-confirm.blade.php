columns: [
    {data: 'check',               name: 'check', orderable: false, searchable: false},
    {data: 'DT_RowIndex',         name: 'DT_RowIndex', orderable: false, searchable: false},
    {data: 'attendance_id',       name: 'attendance_id'},
    {data: 'employee_name',       name: 'employee_name'},              
    {data: 'workingData',         name: 'workingData'},
    {data: 'date_leave',          name: 'date_leave'},                             
    {data: 'time_leave',          name: 'time_leave'}, 
    {data: 'leave_permission_id', name: 'leave_permission_id'},                                                                         
    {data: 'approval1',           name: 'approval1'},                                           
    {data: 'approval2',           name: 'approval2'},                                           
    {data: 'updated_at',          name: 'updated_at'},                                           
]