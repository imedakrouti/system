columns: [
    {data: 'check',               name: 'check', orderable: false, searchable: false},
    {data: 'DT_RowIndex',         name: 'DT_RowIndex', orderable: false, searchable: false},
    {data: 'studentImage',        name: 'studentImage'},
    {data: 'application_date',    name: 'application_date'},
    {data: 'studentName',         name: 'studentName'},
    {data: 'student_number',      name: 'student_number'},
    {data: 'student_type',        name: 'student_type'},
    {data: 'registration_status', name: 'registration_status'},
    {data: 'religion',            name: 'religion'},              
    {data: 'grade',               name: 'grade'},
    {data: 'division',            name: 'division'},              
    {data: 'moreBtn',             name: 'moreBtn', orderable: false, searchable: false},                            
]