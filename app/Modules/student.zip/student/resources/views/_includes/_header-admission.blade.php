<div class="right-header">
    {{$schoolName}} <br>
    {{ trans('student::local.admission_department') }}
</div>

<div class="left-header">
    <img src="{{$logo}}" alt="" class="logo">
</div>
<div class="clear"></div>